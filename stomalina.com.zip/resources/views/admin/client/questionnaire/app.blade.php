<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="{{asset('style/anketa.css')}}">
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
      </style>
    <title>Document</title>
</head>
<body>
 @yield('content')
</body>
</html>