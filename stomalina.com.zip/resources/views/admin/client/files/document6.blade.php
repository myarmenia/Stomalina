<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 7.2.6.2 (Linux)"/>
	<meta name="author" content="IDENT"/>
	<meta name="created" content="00:00:00"/>
	<meta name="changed" content="00:00:00"/>
	<style type="text/css">
		@page { size: 8.27in 11.69in; margin-left: 1.18in; margin-right: 0.59in; margin-top: 0.69in; margin-bottom: 0.37in }
		p { line-height: 115%; text-align: left; orphans: 2; widows: 2; margin-bottom: 0.1in; direction: ltr; background: transparent }
		p.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: ru-RU }
		p.cjk { font-family: "Calibri"; font-size: 10pt; so-language: ru-RU }
		p.ctl { font-family: "Times New Roman"; font-size: 10pt; so-language: ar-SA }
	</style>
</head>
<body lang="en-US" link="#000080" vlink="#800000" dir="ltr"><p lang="ru-RU" class="western" align="right" style="line-height: 115%; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i><b>	
        	</b></i></font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Приложение
№1</font></font></font></p>
<p lang="ru-RU" class="western" align="right" style="line-height: 115%; margin-bottom: 0in">
<font color="#000000"> <font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">к
договору на оказание платных</font></font></font></p>
<p lang="ru-RU" class="western" align="right" style="line-height: 115%; margin-bottom: 0in">
<font color="#000000"> <font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">медицинских
 услуг   от {ДатаПервогоПриемаЧислом} г</font></font></font></p>
<p lang="ru-RU" class="western" align="center" style="line-height: 115%; margin-left: -0.5in; margin-top: 0.15in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><b>Информированное
добровольное согласие на оказание
платных стоматологических услуг </b></font></font></font>
</p>
<p lang="ru-RU" class="western" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>Этот</i></font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">
</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>документ
свидетельствует о том, что мне, в
соответствии со ст.ст. 19-23 Федерального
закона N 323-ФЗ </i></font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>«</i></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>Об
основах охраны здоровья граждан в
Российской Федерации</i></font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>»</i></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>,
сообщена вся необходимая информация о
</i></font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>моем
</i></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>предстоящем
лечении, и что я согласен (согласна) с
названными мне условиями проведения
лечения. Данный документ является
необходимым предварительным условием
(разрешением) начала медицинского
вмешательства</i></font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><i>.</i></font></font></p>
<p lang="ru-RU" class="western" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я,
 {{$client->FullName}}, проинформирован(а)
о </font></font></font>
</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<sup>                                                                
       <font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">(фамилия,
имя, отчество пациента) </font></font></sup>
</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">поставленном
диагнозе_____________________________________________________________
</font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">
</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">и
необходимости проведения лечения  зубов
______________________________________________  в соответствии
с согласованным со мной Предварительным
планом лечения.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Этот
документ содержит необходимую для меня
информацию, с тем, чтобы я ознакомился
(ознакомилась) с предлагаемым мне
лечением и мог (могла) либо отказаться
от него, либо дать согласие на проведение
данного лечения.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
понятна информация, предоставленная
врачом, о наличии у меня стоматологических
заболеваний, включая сведения о
результатах обследования, предварительном
диагнозе, вероятности развития осложнений
при отсутствии лечения, возможных
альтернативных вариантах лечения
имеющихся у меня стоматологических
заболеваний и их стоимости, возможных
неблагоприятных последствиях, в том
числе осложнениях. </font></font></font>
</p>
<p lang="ru-RU" class="western" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
соглашаюсь соблюдать режим, все
рекомендации и назначения лечащего
врача, в ходе лечения  и по его  окончании;
а также немедленно сообщать врачу о
любом изменении самочувствия и
согласовывать с врачом прием любых не
 прописанных им лекарственных препаратов</font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">.</font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Хотя
предлагаемое лечение имеет высокий
процент клинического успеха, тем не
менее, я понимаю, что оно является
биологической процедурой и поэтому не
может иметь стопроцентной гарантии на
успех.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
названы и со мной согласованы технологии
(методы) и материалы, которые будут
использоваться в процессе лечения, а
также сроки проведения лечения и его
стоимость.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-top: 0in; margin-bottom: 0.14in">
<br/>
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Врач
понятно объяснил мне, в чем будет
заключаться предложенное лечение и
</font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">всевозможные</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">
осложнения предложенного лечения и
последствия, которые могут возникнуть
как во время лечения, так и после его
окончания.       </font></font></font>
</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
разъяснена необходимость применение
местной инъекционной анестезии с целью
обезболивания медицинских манипуляций.
Местная анестезия проводится в области
выполняемой манипуляции и предусматривает
одну или несколько инъекций (уколов) с
использованием одноразовых игл и карпул.
Длительность эффекта может варьироваться
от 15 минут до нескольких часов в
зависимости от вида анестетика и
индивидуальной восприимчивости организма
и проявляется в потере чувствительности
в области обезболивания и временном
ощущении припухлости.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
разъяснено, что применение анестезии
может привести к аллергическим реакциям
организма на медикаментозные препараты,
шоку, травматизации нервных окончаний
и другим осложнениям. Введение раствора
проводится при помощи иглы, что травмирует
мягкие ткани и может вызвать образование
внутреннего кровотечения и гематомы,
отечность десны, ограничение открывания
рта, которые могут сохраняться в течение
нескольких дней и дольше.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
разъяснено, что обезболивание затруднено
при выраженном стрессе, в области
существующего воспаления, в области
моляров нижней челюсти, после употребления
алкогольных или наркотических веществ.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
осведомлен(а) о возможных осложнениях
во время приема анальгетиков или
антибиотиков.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
проинформировал(а) лечащего врача обо
всех случаях аллергии к медикаментозным
препаратам и лекарственным средствам
в прошлом и об аллергии в настоящее
время, а так же о всех имеющихся у меня
заболеваниях.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
информирован(а) о необходимости
рентгенологического исследования
челюстей до лечения, во время лечения
и при проведении периодических контрольных
осмотров и согласен(а) на их проведение.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
информирован(а), что при отказе от
рентгенологического обследования врач
не сможет провести качественное лечение,
исключить осложнения после лечения,
поэтому значительно ограничит гарантийный
срок. Я информирован(а) о противопоказаниях
и возможных осложнениях рентгенологического
обследования.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мне
сообщено, что при проведении
рентгенологического обследования
соблюдаются необходимые меры радиационной
безопасности и предоставляются
индивидуальные средства защиты. Доза
моего облучения во время обследования
будет зарегистрирована в медицинской
карте в Листе учета дозовых нагрузок
при проведении рентгенологического
обследования.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Понимая
сущность предложенного лечения и
уникальность собственного организма,
я согласен с тем, что ожидаемый мной
положительный результат лечения не
гарантирован, однако мне гарантировано
проведение лечения специалистом
соответствующей квалификации, применение
им качественных материалов и инструментов
с соблюдением соответствующих методик
и правил санитарно-эпидемиологического
режима.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
получил(а) полную информацию о гарантийном
сроке лечение и ознакомлен(а) с условиями
предоставлении гарантии, которые
обязуюсь соблюдать. Я понимаю, что в
случае их несоблюдения я лишаюсь права
на гарантию.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
понимаю, что в случае возникновения
осложнений указанного заболевания, о
которых я информирован(а) в настоящем
документе и которые возникли вследствие
естественных изменений моего организма,
стоимость повторного лечения взимается
на общих основаниях в полном объеме.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Мной
заданы все интересующие меня вопросы
о сути и условиях лечения и получены
исчерпывающие ответы на них. Я понял(а)
значение всех слов и медицинских
терминов, имеющихся в настоящем документе.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
разрешаю использовать информацию о
моем заболевании, фотографии моих зубов
и полости рта без указания имени и
фамилии в научных и учебных целях, для
публикации в научной литературе, а также
предоставлять об объеме и стоимости
оказанных услуг моему Страховщику.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
внимательно ознакомился (ознакомилась)
с данным документом, являющимся
неотъемлемой частью медицинской карты
(истории болезни) пациента и понимаю,
что его подписание влечет правовые
последствия.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0.14in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Я
подтверждаю свое согласие на медицинское
вмешательство для осуществления лечения
на предложенных условиях, о чем
расписываюсь собственноручно.</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Подпись
пациента: ___________________________/ </font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">{{$client->FullName}}
</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">/</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<font color="#000000"><sup>                                          
                                          <font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">(подпись)
                                                            (ФИО
полностью)</font></font></sup></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Беседу
провел врач: __________________________ /
</font></font></font><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">{ФамилияИмяОтчествоВрача}</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">/</font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<font color="#000000">                                               
       </font><font color="#000000"><sup>  <font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">(подпись)
                                                           
(расшифровка подписи)</font></font></sup></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 115%; margin-left: -0.5in; margin-right: 0.02in; margin-top: 0in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt">Дата:
  {ТекущаяДатаПолная} г</font></font></font></p>
</body>
</html>