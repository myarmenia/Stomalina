<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoBodyText, li.MsoBodyText, div.MsoBodyText
	{margin-top:3.45pt;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:6.1pt;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
@page WordSection1
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection1
	{page:WordSection1;}
@page WordSection2
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection2
	{page:WordSection2;}
@page WordSection3
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection3
	{page:WordSection3;}
@page WordSection4
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection4
	{page:WordSection4;}
@page WordSection5
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection5
	{page:WordSection5;}
@page WordSection6
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection6
	{page:WordSection6;}
@page WordSection7
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection7
	{page:WordSection7;}
@page WordSection8
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection8
	{page:WordSection8;}
@page WordSection9
	{size:595.5pt 842.0pt;
	margin:53.0pt 37.0pt 14.0pt 79.0pt;}
div.WordSection9
	{page:WordSection9;}
 /* List Definitions */
 ol
	{margin-bottom:0in;}
ul
	{margin-bottom:0in;}
-->
body {
        font-family: "Times New Roman", Times, Serif, Arial, Helvetica, sans-serif;
    }
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<p class=MsoNormal align=center style='margin-top:2.6pt;margin-right:0in;
margin-bottom:0in;margin-left:.75pt;margin-bottom:.0001pt;text-align:center'><a
name="_Hlk99915079"><b><span lang=RU style='font-size:14.0pt;font-family:"Times New Roman",serif;
letter-spacing:-.05pt'>Доверенность</span></b></a></p>

<p class=MsoNormal style='line-height:9.0pt'><span lang=RU style='font-size:
9.0pt'>&nbsp;</span></p>

</div>

<span lang=RU style='font-size:9.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection2>

<p class=MsoNormal style='margin-top:3.2pt;margin-right:0in;margin-bottom:0in;
margin-left:6.1pt;margin-bottom:.0001pt'><span style='position:absolute;
z-index:-1895822336;left:0px;margin-left:135px;margin-top:23px;width:617px;
height:1px'><img width=617 height=1 src="2_files/image001.png"></span><span
lang=RU style='font-size:14.0pt;font-family:"Times New Roman",serif;letter-spacing:
-.05pt'>Я,  {{$client->FullName}}</span><span lang=RU style='font-size:14.0pt;font-family:"Times New Roman",serif;
letter-spacing:-.1pt'> </span><u><span lang=RU style='font-size:14.0pt;
font-family:"Times New Roman",serif'></span></u></p>

<span lang=RU style='font-size:11.0pt;font-family:"Calibri",sans-serif'><br
clear=all>
</span>

<p class=MsoNormal style='margin-top:.15pt;line-height:9.5pt'></p>

<p class=MsoNormal style='line-height:12.0pt'><span lang=RU style='font-size:
12.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in'><a name="_Hlk99972792"><span
lang=RU style='font-size:11.0pt'>(ФИО<span style='letter-spacing:-.05pt'> </span>родителя
/ <span style='letter-spacing:-.05pt'>законного</span> <span style='letter-spacing:
-.05pt'>представителя</span> <span style='letter-spacing:-.05pt'>несовершеннолетнег</span></span></a><span
lang=RU style='font-size:11.0pt;letter-spacing:-.05pt'>о</span></p>

</div>

<span lang=RU style='font-size:11.0pt;font-family:"Times New Roman",serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection3>

<p class=MsoNormal style='margin-top:.15pt;line-height:12.0pt'><span lang=RU
style='font-size:12.0pt'>&nbsp;</span></p>

<p class=MsoBodyText><a name="_Hlk99972853"><span lang=RU style='letter-spacing:
-.05pt'>Паспорт____________                (серия) {{$client['passport_series'] ?? null}}
(номер)</span></a><u><span lang=RU> {{$client['passport_number'] ?? null}}</span></u></p>

<p class=MsoNormal style='margin-top:.55pt;line-height:14.0pt'><span lang=RU
style='font-size:14.0pt'>&nbsp;</span></p>

</div>

<span lang=RU style='font-size:14.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection4>

<p class=MsoNormal style='margin-top:.3pt;line-height:7.0pt'><span
style='position:absolute;z-index:-1895827456;margin-left:113px;margin-top:5px;
width:617px;height:1px'><img width=617 height=1 src="2_files/image001.png"></span></p>

<p class=MsoNormal style='line-height:12.0pt'><span lang=RU style='font-size:
12.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in'><span style='position:absolute;
z-index:-1895820288;left:0px;margin-left:116px;margin-top:18px;width:617px;
height:1px'><img width=617 height=1 src="2_files/image001.png"></span><span
lang=RU style='letter-spacing:-.05pt'>доверяю</span></p>

<span lang=RU style='font-size:12.0pt;font-family:"Times New Roman",serif'><br
clear=all>
</span>

<p class=MsoBodyText style='margin-left:45.1pt'><span lang=RU style='font-size:
11.0pt'>кем<span style='letter-spacing:-.1pt'> </span><span style='letter-spacing:
-.05pt'>выдан,</span> <span style='letter-spacing:-.05pt'>дата</span><span
style='letter-spacing:.05pt'> </span><span style='letter-spacing:-.05pt'>выдачи</span></span></p>

<p class=MsoNormal style='margin-top:.9pt;line-height:17.0pt'><span lang=RU
style='font-size:17.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in'><span lang=RU style='font-size:
11.0pt;letter-spacing:-.05pt'>(ФИО бабушки,</span><span lang=RU
style='font-size:11.0pt'> <span style='letter-spacing:-.05pt'>дедушки,</span> <span
style='letter-spacing:-.05pt'>няни,</span> дяди, тети<span style='letter-spacing:
-.05pt'> </span>и <span style='letter-spacing:-.05pt'>пр.)</span></span></p>

</div>

<span lang=RU style='font-size:11.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection5></div>

<span lang=RU style='font-size:14.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection6>

<p class=MsoBodyText><span lang=RU style='letter-spacing:-.05pt'>Паспорт___________                 
(серия)</span><u><span lang=RU>________</span></u></p>

<p class=MsoBodyText style='margin-left:0in'><span lang=RU style='letter-spacing:
-.05pt'>(номер</span><u><span lang=RU>)____________</span></u></p>

</div>

<span lang=RU style='font-size:11.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection7>

<p class=MsoNormal style='margin-top:.05pt;line-height:7.0pt'><span lang=RU
style='font-size:7.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='line-height:10.0pt'><span lang=RU style='font-size:
10.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='text-indent:150.0pt'><span style='position:absolute;
z-index:-1895819264;left:0px;margin-left:125px;margin-top:7px;width:617px;
height:1px'><img width=617 height=1 src="2_files/image001.png"></span><span
lang=RU>(кем<span style='letter-spacing:-.1pt'> </span><span style='letter-spacing:
-.05pt'>выдан,</span> <span style='letter-spacing:-.05pt'>дата</span><span
style='letter-spacing:.05pt'> </span><span style='letter-spacing:-.05pt'>выдачи)</span></span></p>

<p class=MsoNormal style='margin-top:.9pt;line-height:17.0pt'><span lang=RU
style='font-size:17.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in'><span lang=RU>представлять мои
интересы во взаимоотношениях с ООО «Блеск-Л»<u> </u></span></p>

<p class=MsoBodyText align=center style='margin-top:2.1pt;text-align:center;
line-height:115%'><span lang=RU>по поводу лечения/обследования моего ребенка</span><span
lang=RU style='font-size:14.0pt;line-height:115%'><br>
<br>
</span></p>

<p class=MsoBodyText align=center style='margin-top:3.45pt;margin-right:203.05pt;
margin-bottom:0in;margin-left:180.15pt;margin-bottom:.0001pt;text-align:center'><span
style='position:absolute;z-index:-1895826432;left:0px;margin-left:113px;
margin-top:2px;width:617px;height:1px'><img width=617 height=1
src="2_files/image001.png"></span><span lang=RU style='letter-spacing:-.05pt'>(ФИО
ребенка)</span></p>

<p class=MsoBodyText style='margin-top:2.05pt'><span lang=RU style='letter-spacing:
-.05pt'>Свидетельство</span><span lang=RU> о <span style='letter-spacing:-.05pt'>рождении_________
(серия)__________             (номер)_____________</span></span></p>

<p class=MsoNormal style='line-height:10.0pt'><span lang=RU style='font-size:
10.0pt'>&nbsp;</span></p>

</div>

<span lang=RU style='font-size:14.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection8>

<p class=MsoNormal style='margin-top:.3pt;line-height:7.0pt'><span lang=RU
style='font-size:7.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='line-height:12.0pt'><span style='position:absolute;
z-index:-1895821312;margin-left:118px;margin-top:8px;width:617px;height:1px'><img
width=617 height=1 src="2_files/image001.png"></span></p>

<p class=MsoBodyText style='margin-top:0in'><span lang=RU>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in'><span lang=RU>в <span
style='letter-spacing:-.05pt'>частности:</span></span></p>

<span lang=RU style='font-size:12.0pt;font-family:"Times New Roman",serif'><br
clear=all>
</span>

<p class=MsoBodyText><span lang=RU><br>
(кем<span style='letter-spacing:-.1pt'> </span><span style='letter-spacing:
-.05pt'>выдан,</span><span style='letter-spacing:.1pt'> </span><span
style='letter-spacing:-.05pt'>дата выдачи)</span></span></p>

</div>

<span lang=RU style='font-size:11.0pt;font-family:"Calibri",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection9>

<p class=MsoNormal style='margin-top:.65pt;line-height:8.0pt'><span lang=RU
style='font-size:8.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-right:26.1pt;text-indent:0in;line-height:
114%'><span lang=RU>-<span style='font:7.0pt "Times New Roman"'>&nbsp; </span></span><span
lang=RU>подписывать от моего имени договор на оказание<span style='letter-spacing:
-.05pt'> </span>платных медицинских услуг моему ребенку<span style='letter-spacing:
-.05pt'> </span>и все приложения к договору;</span></p>

<p class=MsoBodyText style='margin-top:10.15pt;margin-right:5.4pt;margin-bottom:
0in;margin-left:6.1pt;margin-bottom:.0001pt;text-align:justify;text-indent:
0in;line-height:114%'><span lang=RU>-<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span lang=RU style='letter-spacing:-.05pt'>принимать</span><span
lang=RU style='letter-spacing:.95pt'> </span><span lang=RU style='letter-spacing:
-.05pt'>все</span><span lang=RU style='letter-spacing:.85pt'> </span><span
lang=RU>решения<span style='letter-spacing:.9pt'> </span><span
style='letter-spacing:-.05pt'>относительно</span><span style='letter-spacing:
.7pt'> </span>здоровья<span style='letter-spacing:.9pt'> </span><span
style='letter-spacing:-.05pt'>моего</span><span style='letter-spacing:.9pt'> </span><span
style='letter-spacing:-.05pt'>ребенка</span><span style='letter-spacing:.85pt'>
</span>и<span style='letter-spacing:.85pt'> </span>подписывать<span
style='letter-spacing:3.55pt'> </span>добровольные<span style='letter-spacing:
.05pt'> </span>информированные<span style='letter-spacing:.05pt'> </span>согласия
на медицинские вмешательства, отказы от медицинских вмешательств, планы
обследования и лечения;</span></p>

<p class=MsoBodyText style='margin-top:9.75pt;margin-right:0in;margin-bottom:
0in;margin-left:12.3pt;margin-bottom:.0001pt;text-align:justify;text-indent:
-7.0pt'>-<span style='font:7.0pt "Times New Roman"'>&nbsp; </span>оплачивать
лечение <span style='letter-spacing:-.05pt'>ребенка;</span></p>

<p class=MsoBodyText style='margin-top:8.7pt;margin-right:0in;margin-bottom:
0in;margin-left:12.3pt;margin-bottom:.0001pt;text-align:justify;text-indent:
-7.0pt'><span lang=RU>-<span style='font:7.0pt "Times New Roman"'>&nbsp; </span></span><span
lang=RU>получать информацию о здоровье моего ребенка на приеме врачей, в<span
style='letter-spacing:-.05pt'> </span>устной форме, в</span></p>

<p class=MsoBodyText style='margin-top:8.7pt;margin-right:0in;margin-bottom:
0in;margin-left:5.3pt;margin-bottom:.0001pt;text-align:justify'><span lang=RU>виде 
копий<span style='letter-spacing:.1pt'> </span>и<span style='letter-spacing:
.1pt'> </span>выписок<span style='letter-spacing:.1pt'> </span>из<span
style='letter-spacing:.05pt'> </span>медицинской  документации.</span></p>

<p class=MsoNormal style='margin-top:.85pt;line-height:16.0pt'><span lang=RU
style='font-size:16.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:5.3pt;margin-bottom:.0001pt;text-align:justify'><span lang=RU>-
получать справки, финансовые документы, результаты обследования и лечения.</span></p>

<p class=MsoBodyText style='margin-top:8.7pt;margin-right:0in;margin-bottom:
0in;margin-left:5.3pt;margin-bottom:.0001pt;text-align:justify'><span lang=RU>Доверенность
выдана сроком на _____________________ без права передоверия.<br>
<br>
</span></p>

<p class=MsoNormal style='line-height:10.0pt'><span lang=RU style='font-size:
10.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='line-height:10.0pt'><span lang=RU style='letter-spacing:
-.05pt'>____________</span></p>

<p class=MsoBodyText align=center style='margin-top:3.45pt;margin-right:211.35pt;
margin-bottom:0in;margin-left:168.55pt;margin-bottom:.0001pt;text-align:center'><span
style='position:absolute;z-index:-1895818240;left:0px;margin-left:105px;
margin-top:5px;width:617px;height:1px'><img width=617 height=1
src="2_files/image001.png"></span><span lang=RU>ФИО<span style='letter-spacing:
-.05pt'> </span>Подпись</span></p>

<p class=MsoBodyText style='margin-top:2.05pt;margin-right:0in;margin-bottom:
0in;margin-left:86.75pt;margin-bottom:.0001pt'><span lang=RU style='letter-spacing:
-.05pt'>(родителя/законного</span><span lang=RU> <span style='letter-spacing:
-.05pt'>представителя</span><span style='letter-spacing:.05pt'> </span>несовершеннолетнего)<br>
</span><span lang=RU style='font-size:5.0pt'><br>
<br>
<br>
</span></p>

<p class=MsoNormal style='line-height:10.0pt'><span lang=RU style='font-size:
10.0pt'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-left:143.7pt'><span style='position:absolute;
z-index:-1895823360;left:0px;margin-left:113px;margin-top:2px;width:609px;
height:1px'><img width=609 height=1 src="2_files/image002.png"></span><span
lang=RU>ФИО<span style='letter-spacing:-.05pt'> Подпись</span> <span
style='letter-spacing:-.05pt'>(доверенного</span> <span style='letter-spacing:
-.05pt'>лица)</span></span></p>

<p class=MsoNormal style='line-height:7.0pt'><span lang=RU style='font-size:
7.0pt'>&nbsp;</span></p>

<p class=MsoBodyText><span lang=RU>                                        Дата
выдачи доверенности</span><span lang=RU>________________</span></p>

</div>

</body>

</html>
