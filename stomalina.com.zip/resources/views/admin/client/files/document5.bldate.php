<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 7.2.6.2 (Linux)"/>
	<meta name="author" content="IDENT"/>
	<meta name="created" content="00:00:00"/>
	<meta name="changed" content="00:00:00"/>
	<style type="text/css">
		@page { size: 5.83in 8.27in; margin-left: 0.35in; margin-right: 0.35in; margin-top: 0.1in; margin-bottom: 0.1in }
		p { line-height: 115%; text-align: left; orphans: 2; widows: 2; margin-bottom: 0.1in; direction: ltr; background: transparent }
		p.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: ru-RU }
		p.cjk { font-family: "Noto Sans Symbols"; font-size: 10pt; so-language: ru-RU }
		p.ctl { font-family: "Times New Roman"; font-size: 10pt; so-language: ar-SA }
	</style>
</head>
<body lang="en-US" link="#000080" vlink="#800000" dir="ltr"><p lang="ru-RU" class="western" style="line-height: 100%; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" style="line-height: 100%; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="center" style="line-height: 100%; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 7pt"><b>ИНФОРМИРОВАННОЕ
ДОБРОВОЛЬНОЕ СОГЛАСИЕ</b></font></font></font></p>
<p lang="ru-RU" class="western" align="center" style="line-height: 100%; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 7pt"><b>для
детей до 15 лет</b></font></font></font></p>
<p lang="ru-RU" class="western" align="center" style="line-height: 100%; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 7pt"><b>на
выполнение исследований, лечение
заболеваний полости рта</b></font></font></font></p>
<p lang="ru-RU" class="western" align="center" style="line-height: 100%; margin-bottom: 0in">
<font color="#000000">  </font>
</p>
<p lang="ru-RU" class="western" style="line-height: 100%; margin-bottom: 0in">
<font color="#000000">      <font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>г</b></font></font></font><font face="Times New Roman, serif">
</font><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>Москва</b></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>				
                                                                 
{ТекущаяДата} г.</b></font></font></font></p>
<p lang="ru-RU" class="western" style="line-height: 100%; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" align="center" style="line-height: 100%; margin-left: 0.2in; margin-right: 0.1in; margin-bottom: 0in">
<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><i>Настоящее
добровольное согласие составлено в
соответствии со статьей 20 Федерального
Закона РФ № 323-ФЗ от 21.11.2011 г. «Об Основах
охраны здоровья граждан в Российской
Федерации»</i></font></font></font></p>
<p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-left: 0.1in; margin-right: 0.1in; text-indent: 0.3in; margin-top: 0.06in; margin-bottom: 0in">
<br/>

</p>
<ol>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я,
	(отец, мать, опекун - нужное подчеркнуть),
	{Родитель},</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="4" style="font-size: 14pt">
	</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">являясь
	законным представителем ребенка
	{ФамилияИмяОтчество}, получил(а) от
	лечащего врача всю интересующую меня
	информацию о предстоящем лечении
	следующего(их) зуба(ов)
	_____________________________________________ моему ребенку.
	Я</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="4" style="font-size: 14pt">
	</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">доверяю
	врачу  проведение медицинского
	вмешательства моему ребенку и понимаю
	его цель и причины. Мне разъяснены
	состояние здоровья и заболевания
	ребенка, а также характер, порядок и
	содержание всех необходимых диагностических
	и лечебных мероприятий, соответствующих
	установленному и объявленному  диагнозу
	заболевания и стадии его развития.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	ознакомлен(а) с анализами и результатами
	исследований, подтверждающими
	поставленный диагноз ребен</font></font></font><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">ка</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Последствием
	отказа от лечения могут быть различные
	воспалительные заболевания, которые
	могут повлечь за собой осложнения при
	появлении постоянных зубов у моего
	ребенка, а также общего состояния
	организма</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	информирован(а) о характере предстоящих
	исследований/манипуляций, связанном
	с ними риском и возможном развитии
	неприятных ощущений, осложнений и
	последствий 1) болевых ощущениях; 2)
	воспалительных явлениях; 4) обострении
	сопутствующих заболеваний; 5) аллергических
	реакциях.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	проинформирован(а) об альтернативных
	данному виду методах лечения и о
	преимуществах данного вида. Я также
	ознакомлен(а) с планом предлагаемого
	поэтапного медикаментозного лечения
	и действием данных лекарственных
	препаратов, с возможным изменением
	медикаментозной терапии в случае
	непереносимости тех или иных лекарственных
	препаратов, изменением состояния
	здоровья, требующего изменения тактики
	лечения, а также применением других
	лекарственных препаратов и других
	методов лечения, которые могут быть
	назначены врачом.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Мне
	разъяснено, что в ходе выполнения
	медицинских действий может возникнуть
	необходимость выполнения других
	вмешательств, исследований, операций,
	лечебных мероприятий.  Я доверяю Врачу
	и его коллегам принять соответствующее
	профессиональное решение и выполнить
	любые действия, которые Врач сочтет
	необходимыми для установления или
	уточнения диагноза, улучшения состояния
	ребенка.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Учитывая
	физиологические, психологические и
	возрастные особенности ребенка врач
	может предложить альтернативный метод
	лечения – лечение под общим наркозом.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	заявляю, что изложил(а) врачу все
	известные мне данные о состоянии
	здоровья ребенка, наследственных,
	психических и других заболеваниях в
	семье.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	понимаю необходимость регулярных
	осмотров у врача и поэтому обязуюсь
	приходить с моим ребенком на контрольные
	осмотры (по графику, оговоренному с
	врачом).</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	ознакомил(а) лечащего врача о хронических
	заболеваниях ребенка, перечислила
	медикаменты, которые он принимает.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	проинформировал(а) врача обо всех
	случаях аллергии к медикаментозным
	препаратам, которые имелись у моего
	ребенка в прошлом и об аллергии в
	настоящее время.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	осведомлен(а) о возможных осложнениях
	во время анестезии, приеме анальгетиков,
	антибиотиков и аллергических реакциях.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	согласен(а) на проведение метода
	анестезии, выбранного врачом.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	согласен(а) на рентгенологическое
	обследование, необходимое для полноценного
	лечения.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Мне
	объяснены возможные последствия отказа
	от предлагаемого лечения, включая
	осложнения.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Мне
	были объяснены особенности скоротечности
	перехода пораженных детских зубов из
	стадии кариеса в стадию пульпита и
	</font></font></font><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">периодонтита</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	понимаю сущность медицинского
	вмешательства и уникальность растущего
	детского организма, я согласен(а) с тем,
	что никто не может предсказать точный
	результат планируемого лечения и
	ответную реакцию организма ребенка.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	проинформирован(а), что при лечении
	молочных зубов затраченные денежные
	средства </font></font></font><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">возврату</font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">
	не подлежат.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Я
	подтверждаю, что прочитал(а) и понял(а)
	все вышеизложенное, имел(а) возможность
	обсудить с врачом все интересующие и
	непонятные мне вопросы, связанные с
	лечением заболевания моего ребенка и
	последующего реабилитационного периода.
	На все заданные вопросы я получил(а)
	удовлетворившие меня ответы и у меня
	не осталось невыясненных вопросов к
	врачу.</font></font></font></p>
	<li><p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-top: 0.06in; margin-bottom: 0in">
	<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">Мое
	решение является </font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>свободным
	</b></font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">и
	</font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>добровольным</b></font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">
	и представляет собой </font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>информированное
	согласие</b></font></font></font><font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">
	на проведение медицинского вмешательства.</font></font></font></p>
</ol>
<p lang="ru-RU" class="western" align="justify" style="line-height: 100%; margin-left: 0.16in; margin-top: 0.06in; margin-bottom: 0in">
<br/>

</p>
<p lang="ru-RU" class="western" style="line-height: 100%; margin-bottom: 0in">
<br/>

</p>
<table width="506" cellpadding="7" cellspacing="0">
	<col width="239"/>

	<col width="239"/>

	<tr valign="top">
		<td width="239" style="border: none; padding: 0in"><p lang="ru-RU" class="western" align="center" style="orphans: 0; widows: 0">
			<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>Подпись
			представителя ребенка (мать, отец,
			опекун)</b></font></font></font></p>
		</td>
		<td width="239" style="border: none; padding: 0in"><p lang="ru-RU" class="western" align="center" style="orphans: 0; widows: 0">
			<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt"><b>Подпись
			врача  </b></font></font></font>
			</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="239" style="border: none; padding: 0in"><p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0; margin-bottom: 0in">
			<br/>

			</p>
			<p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0; margin-bottom: 0in">
			<br/>

			</p>
			<p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0">
			<font color="#000000"><font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">_____________________________
			/ {Родитель}</font></font></font></p>
		</td>
		<td width="239" style="border: none; padding: 0in"><p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0; margin-bottom: 0in">
			<br/>

			</p>
			<p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0; margin-bottom: 0in">
			<br/>

			</p>
			<p lang="ru-RU" class="western" align="justify" style="orphans: 0; widows: 0">
			<font color="#000000">    <font face="Times New Roman, serif"><font size="1" style="font-size: 6pt">_____________________________
			/{ФамилияИООтветственного} /</font></font></font></p>
		</td>
	</tr>
</table>
<p lang="ru-RU" class="western" align="justify" style="line-height: 100%; orphans: 0; widows: 0; margin-bottom: 0in">
<br/>

</p>
</body>
</html>