@extends('layouts.app', ['title' => __('Clients')])

@section('content')
@include('users.partials.header', [
    'title' => __('Clients'),
    'class' => 'col-lg-7'
])
<div>
    aa
</div>
@endsection
