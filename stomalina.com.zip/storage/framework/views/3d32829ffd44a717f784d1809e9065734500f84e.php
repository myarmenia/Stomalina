


<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="anketa">
          <div class="input_box">
            <p>Цель обследования</p>
            <input class="input_text" type="text" disabled value="<?php echo e($quest[0]['purpose_survey']); ?>">
            
          </div>
            <p>Как вы оцениваете состояние Вашего здоровья</p>
            <div class="rate">
               <div class="us_click">
                <p>Отличное</p>
                <input type="checkbox" disabled <?php if($quest[0]['state_of_health'] == 'Отличное'): ?> checked <?php endif; ?>>
               </div>
               <div class="us_click">
                <p>хорошее</p>
                <input type="checkbox" disabled <?php if($quest[0]['state_of_health'] == 'хорошее'): ?> checked <?php endif; ?>>
               </div>
               <div class="us_click">
                <p>нармалина</p>
                <input type="checkbox" disabled <?php if($quest[0]['state_of_health'] == 'нармалина'): ?> checked <?php endif; ?>>
               </div>
               <div class="us_click">
                <p>плоха</p>
                <input type="checkbox" disabled <?php if($quest[0]['state_of_health'] == 'плоха'): ?> checked <?php endif; ?>>
               </div>
            </div>
        </div>

        <div class="table_box">
            <div class="on_oof">
                <div class="on">
                    <p>ДА</p>
                
                </div>
                <div class="off">
                    <p>НЕТ</p> 
                </div>
            </div>
             <table class="table">
                 <?php $__currentLoopData = $quest[0]['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($data['purpose_survey']); ?></td>
                     <td> <input type="checkbox" disabled <?php if($data['answer'] == 1): ?> checked <?php endif; ?>></td>
                     <td> <input type="checkbox" disabled <?php if($data['answer'] == 0): ?> checked <?php endif; ?>></td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </table>
        </div>

        <!-- ------------------------------------------- -->

        

        <div class="user_message">
            <h1 class="user_hed">ЗАПИШИТЕ ЛЮБУЮ ИНФОРМАЦИЮ О СОСТОЯНИИ ВАШЕГО ЗДОРОВЬЯ, КОТОРУЮ СЧИТАЕТЕ ВАЖНОЙ:</h1>
            <h1 class="user_hed">
                СПИСОК МЕДИКАМЕНТОВ, ПРЕПАРАТОВ, ВИТАМИНОВ, ДОБАВОК, КОТОРЫЕ ВЫ ПРИНИМАЕТЕ
                </h1>

            <div class="userbox">
                <div class="box">
                    <p>Название лекарства</p>
                    <div class="box_itm" style="word-wrap:break-word; display:inline-block;">
                        <?php echo e($quest[0]['name_medicine']); ?>

                    </div>
                </div>
                <div class="box">
                    <p>Цель приема</p>
                    <div class="box_itm" style="word-wrap:break-word; display:inline-block;">
                        <?php echo e($quest[0]['purpose_admission']); ?>

                    </div>
                </div>
            </div>
           
       

        </div>

       
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.client.questionnaire.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\stom\resources\views/admin/client/questionnaire/questionnaire1.blade.php ENDPATH**/ ?>