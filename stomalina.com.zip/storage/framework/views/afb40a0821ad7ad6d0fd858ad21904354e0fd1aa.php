

<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="table-responsive py-4">
        <a class="btn btn-sm btn-primary text-light" href="<?php echo e(route('doctors.create')); ?>">
            <?php echo e(__('Create')); ?>

        </a>
        <table class="table table-flush" id="datatable-basic">
            <thead class="thead-light">
                <tr>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Surname')); ?></th>
                    <th><?php echo e(__('Patronymic')); ?></th>
                    <th><?php echo e(__('JobTitle')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th><?php echo e(__('created_at')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($datas)): ?>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data['name']); ?></td>
                        <td><?php echo e($data['surname']); ?></td>
                        <td><?php echo e($data['middlename']); ?></td>
                        <td><?php echo e($data['job_title']); ?></td>
                        <td><?php echo e($data['status']); ?></td>
                        <td><?php echo e($data['created_at']); ?></td>
                        <td>
                            <a class="btn btn-sm btn-primary text-white" href="<?php echo e(route('doctors.edit',$data['id'])); ?>">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('doctors.destroy',$data['id'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                             <button class="btn btn-sm btn-danger">
                                <i class="fa fa-trash" aria-hidden="true"></i>
                             </button>
                            </form>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($datas->links()); ?>

    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Doctors')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/admin/doctors/index.blade.php ENDPATH**/ ?>