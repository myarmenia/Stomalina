<div class="row align-items-center justify-content-xl-between">
    
</div><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>