


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style/doctor-show.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="specialist">
        <div class="profesor">
            <img src="<?php echo e(route('get_file',['path'=> $doctor->avatar])); ?>">
            <ul class="profesor_itme">
                <li class="name">
                    <?php echo e($doctor->full_name); ?>

                </li>
                <li>
                    <?php echo e($doctor->job_title); ?>

                </li>
            </ul>
        </div>

    </div>
    <hr>
    <div class="above">
        <p class="above_title">Образование</p>
        <?php if($doctor->education): ?>
        <ul>
            <?php $__currentLoopData = $doctor->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e("$data->date г. – $data->desc"); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    <div class="above">
        <p class="above_title">Повышение квалификации</p>
        <?php if($doctor->training): ?>
        <ul>
            <?php $__currentLoopData = $doctor->training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e("$data->date г. – $data->desc"); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/doctors/show.blade.php ENDPATH**/ ?>