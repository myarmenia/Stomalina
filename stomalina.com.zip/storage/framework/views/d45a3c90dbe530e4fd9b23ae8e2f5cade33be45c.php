<div class="row align-items-center justify-content-xl-between">
    
</div><?php /**PATH /var/www/u1604615/stomalina.com/resources/views/layouts/footers/nav.blade.php ENDPATH**/ ?>