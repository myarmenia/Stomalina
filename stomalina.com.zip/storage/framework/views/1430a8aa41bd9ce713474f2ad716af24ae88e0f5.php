<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">

<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:"Calibri Light";
	panose-1:2 15 3 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoFooter, li.MsoFooter, div.MsoFooter
	{mso-style-link:"Footer Char";
	margin:0in;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoBodyText, li.MsoBodyText, div.MsoBodyText
	{mso-style-link:"Body Text Char";
	margin:0in;
	font-size:9.5pt;
	font-family:"Times New Roman",serif;
	color:black;}
p.MsoBodyTextIndent, li.MsoBodyTextIndent, div.MsoBodyTextIndent
	{mso-style-link:"Body Text Indent Char";
	margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.25in;
	text-indent:-17.0pt;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoBodyTextIndent3, li.MsoBodyTextIndent3, div.MsoBodyTextIndent3
	{mso-style-link:"Body Text Indent 3 Char";
	margin:0in;
	text-indent:1.0pt;
	font-size:10.0pt;
	font-family:"Times New Roman",serif;
	color:black;}
p.MsoNoSpacing, li.MsoNoSpacing, div.MsoNoSpacing
	{margin:0in;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
span.BodyTextIndentChar
	{mso-style-name:"Body Text Indent Char";
	mso-style-link:"Body Text Indent";
	font-family:"Times New Roman",serif;}
span.BodyTextIndent3Char
	{mso-style-name:"Body Text Indent 3 Char";
	mso-style-link:"Body Text Indent 3";
	font-family:"Times New Roman",serif;
	color:black;}
span.BodyTextChar
	{mso-style-name:"Body Text Char";
	mso-style-link:"Body Text";
	font-family:"Times New Roman",serif;
	color:black;}
p.a, li.a, div.a
	{mso-style-name:Название;
	mso-style-link:"Название Знак";
	margin:0in;
	text-align:center;
	font-size:14.0pt;
	font-family:"Times New Roman",serif;}
span.a0
	{mso-style-name:"Название Знак";
	mso-style-link:Название;
	font-family:"Times New Roman",serif;}
span.FooterChar
	{mso-style-name:"Footer Char";
	mso-style-link:Footer;
	font-family:"Times New Roman",serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:8.0pt;
	line-height:107%;}
 /* Page Definitions */
 @page  WordSection1
	{size:595.3pt 841.9pt;
	margin:28.35pt 28.35pt 28.35pt 28.35pt;}
div.WordSection1
	{page:WordSection1;}
@page  WordSection2
	{size:595.3pt 841.9pt;
	margin:21.3pt 28.35pt 14.2pt 28.35pt;}
div.WordSection2
	{page:WordSection2;}
-->
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<p class=MsoNormal style='text-align:justify;text-indent:35.4pt'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;color:black'>До
заключения договора Исполнитель в доступной форме уведомляет Потребителя
(Пациента) о том, что несоблюдение указаний (рекомендаций) Исполнителя
(медицинского работника, предоставляющего платную медицинскую услугу), в том
числе назначенного режима лечения, могут снизить качество предоставляемой
платной медицинской услуги, повлечь за собой невозможность ее завершения в срок
или отрицательно сказаться на состоянии здоровья Потребителя, а также
уведомляет Потребителя (Пациента) о возможности получения соответствующих видов
и объемов медицинской помощи без взимания платы в рамках программы
государственных гарантий бесплатного оказания гражданам медицинской помощи. С
территориальной программой государственных гарантий бесплатного оказания
гражданам медицинской помощи ознакомлен.</span></p>

<p class=MsoNormal style='text-align:justify;text-indent:35.4pt;background:
white'><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='text-align:justify;text-indent:35.4pt;background:
white'><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>Для подтверждения законности своего представительства лицу,
представляющему интересы несовершеннолетнего пациента, необходимо предъявить
документ, подтверждающий, что они являются родителями или опекунами (Статья 64,
Семейный кодекс РФ). Для этого нужно предъявить документ, удостоверяющий
личность одного из родителей (опекуна) и свидетельство о рождении ребенка. Эти
документы в оригинале необходимо иметь при первичном обращении за медицинской
помощью. </span></p>

<p class=a style='text-align:justify;text-indent:35.4pt'><b><span lang=RU
style='font-size:12.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></b></p>

<p class=a><b><span lang=RU style='font-size:12.0pt;font-family:"Calibri Light",sans-serif'>Договор
на оказание платных медицинских услуг несовершеннолетнему № ____</span></b></p>

<p class=MsoNormal align=center style='text-align:center'><span lang=RU
style='font-family:"Calibri Light",sans-serif'>подписывается официальным
представителем несовершеннолетнего пациента</span></p>

<p class=MsoNormal><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>г.
Москва                                                                                     
                                                                                    «
____ »_________________20___г.</span></p>

<p class=MsoNormal><span lang=RU style='font-size:11.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>

<div style='border:none;border-bottom:solid black 1.0pt;padding:0in 0in 1.0pt 0in'>

<p class=MsoNormal style='border:none;padding:0in'><b><span lang=RU
style='font-size:11.0pt;font-family:"Calibri Light",sans-serif'>Официальный
представитель,</span></b><span lang=RU style='font-size:11.0pt;font-family:
"Calibri Light",sans-serif'><?php echo e($client->FullName); ?></span></p>

</div>

<p class=MsoNormal align=center style='text-align:center;line-height:150%'><span
lang=RU style='font-size:11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'>(ФИО)</span></p>

<p class=MsoNormal style='line-height:150%'><span lang=RU style='font-size:
11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'><?php echo e($client->dob); ?> года рождения, Паспорт серия <?php echo e($client->passport_series); ?> № <?php echo e($client->passport_number); ?> </span></p>

<p class=MsoNormal style='line-height:150%'><span lang=RU style='font-size:
11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'><?php echo e($client->passport_d_issue); ?> года, адрес <?php echo e($client['address'][0]['FullAddress']); ?>

</span></p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span lang=RU
style='font-size:11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'>Телефон:
<?php echo e($client->phone_number); ?>                </span><span style='font-size:11.0pt;
line-height:150%;font-family:"Calibri Light",sans-serif'>e</span><span lang=RU
style='font-size:11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'>-</span><span
style='font-size:11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'>mail</span><span
lang=RU style='font-size:11.0pt;line-height:150%;font-family:"Calibri Light",sans-serif'>:
<?php echo e($client->email); ?></span></p>

<p class=MsoNormal style='text-align:justify'><b><span lang=RU
style='font-size:11.0pt;font-family:"Calibri Light",sans-serif'>действующий от
имени несовершеннолетнего Пациента </span></b><span lang=RU style='font-size:
11.0pt;font-family:"Calibri Light",sans-serif'>«____» _____________________ 
______ г.р.</span></p>

<p class=MsoNoSpacing style='text-align:justify'><span lang=RU
style='font-family:"Calibri Light",sans-serif'>ФИО<b> ______________________</b>_____________________________________________________________,</span></p>

<p class=MsoNoSpacing><span lang=RU style='font-family:"Calibri Light",sans-serif'>Серия
и номер паспорта/свидетельства о рождении________________________,
выдан_____________________________________________________         «____» _____________
 ______ года,</span></p>

<p class=MsoNoSpacing style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;color:black'>именуемый
в дальнейшем «Пациент» </span><span lang=RU style='font-size:9.0pt;font-family:
"Calibri Light",sans-serif;color:black'>и ООО «Блеск-Л», свидетельство о
присвоении ОГРН 1047796213850, выдано Межрайонной инспекцией МНС России № 46 по
г. <span style='background:white'>Москве в лице представителя Общества,
действующего на основании доверенности № 5 от «6» апреля  2022 года</span></span><span
lang=RU style='font-family:"Calibri Light",sans-serif;color:black;background:
white'> </span><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black;background:white'>и лицензии № ЛО-77-01-011125 от 20.10.2015 г.,
выдана Департаментом Здравоохранения города Москвы (г.Москва, Оружейный</span><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'> переулок, д. 43, стр.1, номер телефона: +7 495 777 77 77) на
осуществление медицинской деятельности при оказании первичной доврачебной
медицинской помощи в амбулаторных условиях по: рентгенологии, сестринскому
делу, стоматологии, стоматологии ортопедической, стоматологии профилактической,
при оказании первичной специализированной медико-санитарной помощи в
амбулаторных условиях по: ортодонтии, стоматологии детской, стоматологии
ортопедической, стоматологии терапевтической, стоматологии хирургической,
именуемое в дальнейшем «Исполнитель», далее совместно именуемые «Стороны»,
заключили настоящий договор о нижеследующем.</span></p>

<p class=MsoNoSpacing style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>Предмет договора</span></u></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>1.1 Исполнитель
обязуется по желанию и с согласия Пациента при наличии медицинских показаний
оказать пациенту платные медицинские услуги, а Пациент – принять и оплатить
оказанные услуги по прайсу Исполнителя в соответствии с условиями настоящего
Договора.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>1.2 Настоящий
договор обеспечивает реализацию прав Пациента на получение платных медицинских
услуг в соответствии с ПП РФ от 4 октября 2012
 г. N 1006 &quot;Об утверждении Правил предоставления медицинскими
организациями платных медицинских услуг&quot; и ФЗ N 323-ФЗ &quot;Об основах
охраны здоровья граждан в Российской Федерации&quot;.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>2. Условия и сроки
предоставления платных медицинских услуг</span></u></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>2.1 Основанием
для предоставления платных медицинских услуг является добровольное желание
Пациента получить медицинские услуги за плату, наличие медицинских показаний и
технической возможности для оказания медицинских услуг.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>2.2. Лечащий
врач, назначаемый по выбору Пациента, в соответствии с медицинскими показаниями
и возможностями, после предварительного собеседования, осмотра и обследования
Пациента, устанавливает предварительный диагноз, определяет возможные варианты
и методы  диагностики и лечения, сроки, последствия лечения и предполагаемые
результаты, степень риска и возможные осложнения, информирует об этом Пациента
и получает его Информированное добровольное согласие, составляет
предварительный план лечения, после чего проводит комплекс диагностических,
лечебных и реабилитационных мероприятий в соответствии с диагнозом и
предварительным планом лечения.  </span></p>

<p class=MsoNormal><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>2.3. Средние сроки оказания услуг по Договору указаны в Положении
о сроках оказания стоматологических услуг в уголке потребителя. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>Сроки оказания
Услуг, а также их объем и стоимость зависят от состояния здоровья Пациента,
диагноза, периода, необходимого для качественного и безопасного оказания услуг,
графика визитов Пациента, расписания работы врача и указываются после
проведения обследования и постановки диагноза в приложениях к Договору -
Предварительном плане (планах) лечения. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>2.4. Перечень
оказываемых медицинских услуг указывается в Предварительном плане лечения,
являющимся приложением к настоящему Договору, который составляется письменно
после обследования и диагностики и который может изменяться по согласованию
сторон и по медицинским показаниям. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>2.5. Подписывая
Договор, Пациент подтверждает, что до заключения Договора ознакомился с
прейскурантом Исполнителя, Положением о гарантиях, Положением о сроках оказания
услуг, с правилами, порядками, условиями, формами оказания медицинских услуг и
их оплаты, с правилами поведения пациентов в клинике Исполнителя, и обязуется
соблюдать их требования и нормы.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3. Права и
обязанности сторон</span></u></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.1 Исполнитель
обязан:</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.1.1. Оказывать
платные медицинские услуги в соответствии с медицинскими показаниями Пациента.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.1.2.
Обеспечить соответствие предоставляемых медицинских услуг порядкам, стандартам
и требованиям, предъявляемым к методам диагностики, профилактики и лечения,
разрешенным на территории Российской Федерации.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.1.3.
Ознакомить Пациента с подробной информацией о предоставляемых медицинских
услугах, планом лечения и стоимостью услуг. При необходимости изменения плана
лечения и стоимости и сроков оказания услуг письменно согласовать изменения с
Пациентом и предоставить дополнительные услуги с его согласия или уведомить о
расторжении Договора при несогласии Пациента с изменениями плана лечения и
рекомендациями врача, несоблюдение которых может повлечь негативные последствия
для здоровья, уведомив Пациента о последствиях. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2 Пациент
обязан:</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.1. Выполнять
требования, обеспечивающие качественное предоставление медицинских услуг, в том
числе: выполнять устные и письменные рекомендации и назначения лечащего врача,
сообщать необходимые сведения о своем состоянии здоровья; соблюдать график
визитов для диагностики, лечения и плановых осмотров. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.2.
Подписывать Информированные добровольные согласия на оказание медицинских
услуг, Предварительный план лечения, Акт приемки-сдачи оказанных услуг и иные
документы и Приложения к настоящему договору. При достижении Пациентом возраста
15 лет он подписывает информированное согласие на проведение медицинского
вмешательства и отказ от проведения медицинского вмешательства самостоятельно и
собственноручно без участия Представителя. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.3. Явиться в
клинику за 10 минут до назначенного времени приема к врачу и уведомлять
Исполнителя за 24 часа об отмене назначенного врачом визита.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.4. Во время
действия настоящего Договора уведомлять Исполнителя об использовании
препаратов, назначенных самостоятельно или специалистами других лечебных
учрежде­ний и не получать стоматологических услуг в других клиниках без
предварительного уведомления Исполнителя (за исключением экстренной медицинской
помощи при угрожающих жизни состояниях).</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.5. В случае
изменения состояния здоровья, связанного, с точки зрения Пациента, с
проведенными Исполнителем медицинскими манипуляциями, немедленно сообщить об
этом лечащему врачу или администратору Исполнителя, и, в случае необходимости,
прибыть на консультацию и лечение к Исполнителю в разумные сроки согласно
врачебным рекомендациям.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.6. При
отказе от продолжения лечения у Исполнителя, Пациент обязан подписать отказ от
медицинского вмешательства и расторгнуть Договор, предварительно оплатив
оказанные услуги и все фактически понесенные Исполнителем затраты по Договору. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.7. После
завершения каждого этапа оказания услуг подписать Акт выполненных услуг и(или)
акт сверки. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.8. Посещать
клинику Исполнителя 1 раз в 4 месяца для бесплатного планового
профилактического осмотра.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.9.
Неукоснительно соблюдать установленные Исполнителем назначения, рекомендации,
правила поведения и условия гарантии.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.10. Оплатить
оказанные Исполнителем услуги по Договору в соответствии с прайсом на момент
оказания услуги.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.2.11.
Заботиться о своем здоровье, принимать все возможные меры для сохранения
положительного результата лечения.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3 Исполнитель
имеет право:</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.1. Изменять
с согласия потребителя по медицинским показаниям и экономическим причинам
предварительный план, вид, объем, сроки и стоимость оказания платных
медицинских услуг. В случае несогласия потребителя договор расторгается. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.2.
Направлять Пациента с его согласия в другие медицинские организации или
привлекать для консультаций и лечения внешних специалистов для оказания
дополнительных медицинских услуг, которые осуществляются за отдельную плату.  </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.3.
Установить гарантийные обязательства и сроки службы на оказанные услуги
индивидуально в соответствии с Приложениями к настоящему Договору, указывать их
в акте выполненных услуг, гарантийном талоне, иных документах.  </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.4.
Расторгнуть данный Договор при невозможности оказать в данном клиническом
случае необходимую Пациенту медицинскую услугу силами Исполнителя ввиду
отсутствия технической возможности или необходимой компетенции медицинского
персонала. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.5. Направить
Пациента (с его согласия) к другому специалисту соответствующего профиля в
случае непредвиденного отсутствия лечащего врача в день приема, или перенести
визит и увеличить сроки оказания услуг.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.3.6. Отсрочить
или отменить оказание услуги (в том числе в день назначения) и изменить сроки
оказания услуг в случае обнаружения у Пациента медицинских противопоказаний как
со стороны полости рта, так и по общему состоянию здоровья.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.4 Пациент
имеет право:</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.4.1. Получать
информацию о состоянии своего здоровья, о результатах оказания медицинских
услуг, о действии лекарственных пре­паратов и их побочных проявлениях, об исходах
и прогнозах стоматологических вмешательств.</span></p>

<p class=MsoBodyText style='text-align:justify'><span lang=RU style='font-size:
9.0pt;font-family:"Calibri Light",sans-serif'>3.4.2. На<span style='letter-spacing:
.25pt'> </span>выбор<span style='letter-spacing:.15pt'> лечащего </span>врача<span
style='letter-spacing:.15pt'> </span>с<span style='letter-spacing:.4pt'> </span><span
style='letter-spacing:-.05pt'>учетом</span><span style='letter-spacing:.15pt'>
получения </span>согласия<span style='letter-spacing:.2pt'> </span>врача
осуществлять лечение пациента.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.4.3. Получить
выписку, описание и копии из медицинской документации в сроки, установленные
законодательством РФ.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>3.4.4.
Расторгнуть Договор в любой момент посредством предоставления письменного
отказа от лечения при условии полной оплаты выполненных по Договору платных
медицинских услуг и всех понесенных Исполнителем затрат. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>4. Порядок
оплаты</span></u></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>4.1 Пациент производит
оплату медицинских услуг по прайсу Исполнителя на день оказания услуг одним из
следующих способов: наличными денежными средствами в кассу, безналичным
перечислением денежных средств на расчетный счет, с использованием платежного
терминала Исполнителя и банковских карт. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>4.2 С согласия
пациента медицинские услуги по плану лечения могут быть оплачены в полном
размере предоплатой или частично путем внесения аванса. При досрочном
расторжении Договора делается перерасчет за фактически оказанные услуги и возврат
остатка ранее внесенного аванса Пациенту наличными или на расчетный счет в
банке в срок до 10 банковских дней включительно. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>4.3 В случае
согласованного с пациентом изменения стоимости оказываемых Исполнителем платных
медицинских услуг в процессе лечения делается перерасчет и производится оплата
услуг по прайсу на момент оказания услуги с учетом этих изменений. Исполнитель
может изменить свой прайс в любое время. Гарантия сохранения стоимости услуг по
предварительному плану лечения сохраняется только при согласии Пациента на
внесение предоплаты за предполагаемые по плану лечения услуги и оплате этих
услуг авансом. В случае задержки оплаты по Договору начисляется пеня в размере
0,5% за каждый день просрочки. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.
Ответственность сторон </span></u></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.1. За неисполнение
или ненадлежащее исполнение обязательств по настоящему договору стороны несут
ответственность в соответствии с текущим разделом настоящего Договора. В
случаях, не урегулированных данным разделом, стороны несут ответственность в
соответствии с действующим законодательством РФ.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.2. В случае
неблагоприятного исхода лечения в связи с нарушением пациентом врачебных
рекомендаций и режима лечения; с возникновением ожидаемых осложнений лечения;
при не наступлении результата лечения по причинам, возможность возникновения
которых была указана и согласована с Пациентом при получении Информированного
добровольного согласия на оказание платных медицинских услуг и иных приложений
к настоящему Договору, предъявления претензий Пациента по качеству оказания
медицинских услуг после вмешательства самого пациента или специалиста другой
клиники в гарантийную стоматологическую конструкцию или после получения в
другой клинике стоматологических услуг, способных прямо или косвенно повлиять
на гарантийную стоматологическую конструкцию, а также при нарушении Пациентом
условий гарантии, а также после истечения сроков гарантии и сроков службы
овеществленных результатов медицинских услуг, Исполнитель ответственности не
несет. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.3. Нарушение
Пациентом правил поведения в клинике Исполнителя, повторное опоздание Пациента
более чем на 15 минут или неявка на прием без уважительной причины и
уведомления Исполнителя не позднее чем за 24 часа, невыполнение рекомендаций и
назначений врача, в том числе режима лечения по срокам оказания услуг, отказ
Пациента от продолжения лечения, появление в клинике Исполнителя в состоянии
алкогольного или наркотического опьянения, а также нарушения Пациентом
обязательств, предусмотренных пунктами настоящего Договора, являются основанием
для снятия с Исполнителя ответственности за последствия таких действий
Пациента, а также для прекращения гарантийных обязательств по всем ранее
оказанным Исполнителем платным медицинским услугам, если данные действия
пациента могут стать причиной наступления факторов, препятствующих оказанию
безопасной и качественной медицинской помощи и снизить качество ранее оказанных
услуг, а также причинить прямой и косвенный вред здоровью Пациента.</span></p>

<p class=MsoBodyText style='margin-right:5.7pt;text-align:justify'><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.4. В<span
style='letter-spacing:2.6pt'> </span>отношении<span style='letter-spacing:2.75pt'>
</span><span style='letter-spacing:-.05pt'>услуги,</span><span
style='letter-spacing:2.75pt'> </span>на<span style='letter-spacing:2.75pt'> </span><span
style='letter-spacing:-.05pt'>которую</span><span style='letter-spacing:.1pt'> </span><span
style='letter-spacing:-.05pt'>установлен</span><span style='letter-spacing:
2.8pt'> </span>гарантийный<span style='letter-spacing:2.65pt'> </span>срок,<span
style='letter-spacing:2.6pt'> </span>исполнитель<span style='letter-spacing:
1.25pt'> </span>отвечает<span style='letter-spacing:1.15pt'> </span>за<span
style='letter-spacing:1.15pt'> </span>ее<span style='letter-spacing:1.15pt'> </span>недостатки,<span
style='letter-spacing:1.2pt'> </span>если<span style='letter-spacing:1.2pt'> </span>не<span
style='letter-spacing:1.2pt'> </span>докажет,<span style='letter-spacing:1.25pt'>
</span><span style='letter-spacing:-.05pt'>что</span><span style='letter-spacing:
1.25pt'> </span>они<span style='letter-spacing:1.25pt'> </span><span
style='letter-spacing:-.05pt'>возникли</span><span style='letter-spacing:1.2pt'>
</span>после<span style='letter-spacing:1.6pt'> </span>принятия<span
style='letter-spacing:.6pt'> </span><span style='letter-spacing:-.05pt'>услуги</span><span
style='letter-spacing:.65pt'> </span>потребителем<span style='letter-spacing:
.55pt'> </span>вследствие<span style='letter-spacing:.65pt'> </span>нарушения<span
style='letter-spacing:.65pt'> </span>им<span style='letter-spacing:.6pt'> </span>правил<span
style='letter-spacing:1.7pt'> </span>использования<span style='letter-spacing:
1.1pt'> </span>результата<span style='letter-spacing:1.2pt'> </span>услуги,<span
style='letter-spacing:1.15pt'> </span>действий<span style='letter-spacing:1.15pt'>
</span><span style='letter-spacing:-.05pt'>третьих</span><span
style='letter-spacing:1.15pt'> </span>лиц<span style='letter-spacing:1.15pt'> </span>или<span
style='letter-spacing:1.2pt'> </span>непреодолимой<span style='letter-spacing:
-1.3pt'> </span>силы. К ним, в частности, относятся травмы, операции,<span
style='letter-spacing:2.4pt'> </span>появление<span style='letter-spacing:2.3pt'>
</span>или<span style='letter-spacing:.2pt'> </span><span style='letter-spacing:
-.05pt'>обострение</span><span style='letter-spacing:.5pt'> </span>у<span
style='letter-spacing:.1pt'> </span>Пациента<span style='letter-spacing:.2pt'> </span>в<span
style='letter-spacing:.2pt'> </span>период<span style='letter-spacing:.25pt'> </span>гарантийного<span
style='letter-spacing:.35pt'> </span><span style='letter-spacing:-.05pt'>срока</span><span
style='letter-spacing:.2pt'> </span>заболеваний,<span style='letter-spacing:
2.4pt'> </span>а<span style='letter-spacing:2.3pt'> </span><span
style='letter-spacing:-.05pt'>также</span><span style='letter-spacing:2.3pt'> </span>изменения<span
style='letter-spacing:2.4pt'> </span>состояния<span style='letter-spacing:2.35pt'>
</span>организма<span style='letter-spacing:1.8pt'> </span>(вследствие<span
style='letter-spacing:2.0pt'> </span>беременности,<span style='letter-spacing:
2.05pt'> </span><span style='letter-spacing:-.05pt'>приема</span><span
style='letter-spacing:2.05pt'> </span>лекарственных<span style='letter-spacing:
2.05pt'> </span>препаратов,<span style='letter-spacing:1.4pt'> </span>вредных<span
style='letter-spacing:.9pt'> </span>внешних<span style='letter-spacing:1.1pt'> </span>воздействий),<span
style='letter-spacing:1.1pt'> </span><span style='letter-spacing:-.05pt'>которые</span><span
style='letter-spacing:.9pt'> </span>напрямую<span style='letter-spacing:.95pt'>
</span>или<span style='letter-spacing:1.0pt'> </span>косвенно<span
style='letter-spacing:.95pt'> </span>приводят<span style='letter-spacing:.95pt'>
</span>к<span style='letter-spacing:1.45pt'> </span>изменениям<span
style='letter-spacing:-.5pt'> </span>в<span style='letter-spacing:-.45pt'> </span>зубах,
зубных протезах, имплантатах  и<span style='letter-spacing:-.3pt'> </span>окружающих<span
style='letter-spacing:-.45pt'> </span>их<span style='letter-spacing:-.45pt'> </span>тканях
челюстно-лицевой области.</span></p>

<p class=MsoBodyText style='margin-right:5.7pt;text-align:justify'><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>5.5
Исполнитель уведомляет Потребителя о том, что при оказании медицинских услуг
положительный ожидаемый результат лечения, а тем более полное излечение, как
результат оказываемых услуг, не может быть гарантировано. Успешность
медицинских вмешательств оценивается путем прогнозов на исходы различных
заболеваний, о которых Пациенту сообщается устно и в момент подписания
Информированного добровольного согласия на медицинское вмешательство,
являющегося самостоятельным юридическим документом.  </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>6. <u>Порядок
разрешения споров</u></span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>6.1. Понимая
субъективность оценки эстетического и функционального результатов медицинских
услуг, в случае возникновения разногласий по вопросу качества оказанных по
Договору услуг, Стороны договорились проводить оценку результатов оказанных
услуг на совместном заседании Пациента и Врачебной Комиссии Исполнителя.
Стороны договорились о том, что качество оказанных платных медицинских услуг
должно соответствовать Договору. Срок устранения признанных Исполнителем
претензий по Договору назначается Пациентом равным 6 месяцам. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7. <u>Прочие
условия</u></span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.1. Стоимость
медицинских услуг, согласованная с Пациентом после осмотра и диагностики,
является предварительной и не включает стоимость лечения скрытых патологий,
которые могут быть обнаружены в процессе лечения. Точная стоимость определяется
в процессе и после лечения и может отличаться от предварительной. Пациент
обязуется оплатить фактически оказанные услуги по мед.показаниям, о возможности
оказания которых он был предупрежден заранее, даже если они не были включены в предварительный
план лечения.  </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.2. Оригиналы
медицинских документов Исполнителя Пациенту не выдаются. Пациент имеет право
ознакомиться с оригиналами медицинских документов в соответствии с правилами,
утвержденными приказом МЗ РФ №425н. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.3. Подписывая
настоящий Договор, Пациент наделяет Исполнителя правом, при необходимости,
провести оценку качества и эстетического результата оказанных Пациенту
медицинских услуг, разрешая при этом передачу врачам, проводящим оценку
качества, персональных данных и информации о состоянии своего здоровья,
содержащейся в медицинской карте с условием сохранения ими конфиденциальности
персональных данных и медицинской тайны. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.4. Пациент, в
соответствии с требованиями статьи 9 федерального закона № 152-ФЗ “О
персональных данных”, дает свое согласие на обработку персоналом Исполнителя
своих персональных данных, включающих: фамилию, имя, отчество, гражданство,
пол, дату рождения, адрес места жительства, контактные телефоны и адреса
электронной почты, реквизиты полиса ДМС, данные о состоянии своего здоровья и
иные персональные данные в медико-профилактических целях, для установления
медицинского диагноза и оказания медицинских услуг, в целях уведомления об
услугах и акциях по почте, электронной почте и сотовой связи посредством телефонных
звонков и СМС, сбора статистической информации, контроля качества лечения. В
процессе оказания медицинской помощи Пациент дает право Исполнителю передавать
свои персональные данные, фотографии и сведения, составляющие врачебную тайну,
третьим лицам в интересах своего обследования и лечения. Срок хранения
персональных данных соответствует сроку хранения первичных медицинских
документов. Настоящее согласие действует бессрочно и может быть отозвано
Пациентом в письменном виде заказным письмом. Пациент уведомлен о необходимости
медицинского фото- и видеопротоколирования этапов оказания мед. услуг и дает на
это свое согласие. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.5. Все
приложения и дополнительные соглашения, указанные в настоящем Договоре и
созданные Сторонами в процессе действия Договора, рассматриваются Сторонами как
неотъемлемые составные части настоящего Договора.</span></p>

<p class=MsoNormal style='text-align:justify;background:white;vertical-align:
baseline'><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>7.6. Подписывая данный Договор, Пациент подтверждает, что делает
это сознательно и добровольно, без принуждения и давления обстоятельств, имея
альтернативные варианты выбора врача и лечебного учреждения, в том числе по
программе гос. гарантий ОМС.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>7.7. В случае
лечения пациента по договору добровольного медицинского страхования все услуги,
относящиеся к страховому случаю (подтверждается направлением от страховой
компании), оплачиваются страховой компанией. Прочие услуги, на которые не
распространяется действие страхового полиса ДМС, оплачиваются пациентом в
соответствии с условиями настоящего Договора. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>8. </span></u><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>Гарантийные
сроки устанавливаются только на услуги, имеющие овеществлённый результат. На
профессиональную гигиену, отбеливание, хирургические манипуляции и прочие не
овеществлённые результаты услуг гарантии выражаются в качественном оказании
услуг согласно принятым методикам лечения. Гарантийные обязательства полностью
утрачиваются при нарушении условий настоящего Договора, положения о гарантиях,
врачебных рекомендаций, в том числе графика визитов и режима лечения. Полная
информация о сроках и условиях гарантии, сроках службы овеществленных
результатов услуг Исполнителя содержится в «Положении о гарантиях» на интернет-сайте
www.</span><span style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>stomalina</span><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>.</span><span
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>ru</span><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'> и на
информационном стенде Исполнителя. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>9. Срок
действия, изменение и расторжение Договора</span></u></p>

<p class=MsoNormal style='text-align:justify'><span lang=RU style='font-size:
9.0pt;font-family:"Calibri Light",sans-serif;color:black'>9.1. Настоящий
Договор вступает в силу с момента его подписания сторонами и действует в
течение одного календарного года с момента вступления его в силу. Договор может
быть пролонгирован на тех же условиях на следующий календарный год в случае,
если за 10 дней до истечения срока действия настоящего договора ни одна из
Сторон не известит в письменной форме другую Сторону о намерении расторгнуть
настоящий договор.</span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>9.2. Изменения и
дополнения настоящего Договора возможны только путем составления письменного
Приложения или Дополнительного соглашения и его подписания всеми сторонами
Договора. </span></p>

<p class=MsoBodyTextIndent3 style='text-align:justify'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>9.3. Расторжение
договора возможно по факту выполнения Сторонами всех обязательств по Договору,
по инициативе Потребителя, по обоюдному соглашению Сторон путем направления
письменного предложения о расторжении Договора, по окончанию срока действия, по
решению суда либо по иным причинам согласно законодательству РФ.</span></p>

<p class=MsoBodyTextIndent3 style='text-indent:0in'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>

<p class=MsoBodyTextIndent3 style='text-indent:0in'><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>9.4.<u> </u>Настоящий
Договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, по
одному для каждой из сторон.</span></p>

<p class=MsoBodyTextIndent3 style='text-indent:0in'><u><span lang=RU
style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>10. Реквизиты
сторон:</span></u></p>

</div>

<b><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'><br clear=all style='page-break-before:auto'>
</span></b>

<div class=WordSection2>

<p class=MsoBodyTextIndent style='margin-left:0in;text-align:justify'><span
lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>                      </span></p>

<p class=MsoBodyTextIndent style='margin-left:0in;text-align:justify;
text-indent:56.7pt'><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
color:black'>&nbsp;</span></p>

<div align=center>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=738
 style='width:553.2pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=369 valign=top style='width:276.6pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoBodyText align=center style='text-align:center'><span lang=RU
  style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>«Исполнитель»</span></p>
  </td>
  <td width=369 valign=top style='width:276.6pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoBodyTextIndent align=center style='text-align:center'><span
  lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
  color:black'>«Заказчик»</span></p>
  </td>
 </tr>
 <tr style='height:100.9pt'>
  <td width=369 valign=top style='width:276.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:100.9pt'>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>ООО
  «Блеск-Л»</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>105043
  г. Москва, Первомайская ул., д.58Б., стр.1, этаж 1, помещение I, комнаты
  31,32,33,16</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>+7
  495 419 95 11</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>ИНН:7719512258</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>КПП:771901001</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>р/сч:
  40702810938000065622</span></p>
  <p class=MsoNormal style='text-align:justify;line-height:12.0pt'><span
  lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
  color:black'>к/сч: 30101810400000000225</span></p>
  <p class=MsoNormal style='text-align:justify;line-height:12.0pt'><span
  lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal style='text-align:justify;line-height:12.0pt'><span
  lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif;
  color:black'>В лице представителя Общества, действующего от имени исполнителя
  на основании доверенности № 5 от 06 апреля 2022 года. </span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>Подпись:
  _________________/ Четверткова Елена Валерьевна                                                ­­­­­­­­­­</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>МП</span></p>
  </td>
  <td width=369 valign=top style='width:276.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:100.9pt'>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>Фамилия:______________________________________</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>Имя__________________________________________</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>Отчество_____________________________________</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  <p class=MsoBodyText style='margin-left:.25in'><span lang=RU
  style='font-size:10.0pt;font-family:"Calibri Light",sans-serif'>Подпись:
  _____________________­­­­­­­­­­­­­­­­_</span></p>
  <p class=MsoBodyText><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>
  </td>
 </tr>
</table>

</div>

<p class=MsoBodyTextIndent style='margin-left:0in;text-align:justify;
text-indent:56.7pt'><span lang=RU style='font-size:9.0pt;font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>

<p class=MsoBodyText align=center style='text-align:center'><span lang=RU
style='font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>

<p class=MsoBodyText align=center style='text-align:center'><span lang=RU
style='font-family:"Calibri Light",sans-serif'>&nbsp;</span></p>

<p class=MsoNormal><span lang=RU>&nbsp;</span></p>

</div>

</body>

</html>
<?php /**PATH D:\WEB Programms\htdocs\narek\stom\resources\views/admin/client/files/document3.blade.php ENDPATH**/ ?>