


<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="table_box">
         <div class="on_oof">
             <div class="on">
                 <p>ДА</p>
             
             </div>
             <div class="off">
                 <p>НЕТ</p> 
             </div>
         </div>
 
         <table class="table">
          <?php $__currentLoopData = $quest[0]['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($data['purpose_survey']); ?></td>
              <td> <input type="checkbox" disabled <?php if($data['answer'] == 1): ?> checked <?php endif; ?>></td>
              <td> <input type="checkbox" disabled <?php if($data['answer'] == 0): ?> checked <?php endif; ?>></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.client.questionnaire.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\stom\resources\views/admin/client/questionnaire/questionnaire2.blade.php ENDPATH**/ ?>