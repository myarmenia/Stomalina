

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="py-4">
    <form method="POST" action="<?php echo e(route('doctors.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" value="<?php echo e($doctor['name']); ?>" name="name">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" value="<?php echo e($doctor['middlename']); ?>" name="middlename">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" value="<?php echo e($doctor['surname']); ?>" name="surname">
                </div>
              </div>
        </div>
        <div class="row">
          <div class="col-md-12">
              <img src="" alt="">
          </div>
        </div>
         <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="avatar">
                        <label class="custom-file-label"><?php echo e(__('Choose Avatar')); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <textarea class="form-control form-control-alternative" rows="3" name="job_title"><?php echo e($doctor['job_title']); ?></textarea>
            </div>
        </div>
        <div class="row py-4 text-center">
            <div class="col-md-12">
                <button class="btn btn-primary">
                    <?php echo e(__('Save')); ?>

                </button>
            </div>
        </div>
       
      </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Edit Doctor')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/admin/doctors/edit.blade.php ENDPATH**/ ?>