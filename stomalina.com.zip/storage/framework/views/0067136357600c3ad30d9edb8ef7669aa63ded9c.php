

<?php $__env->startSection('content'); ?>
<?php if(isset($client)): ?>
<div class="container">
    <div class="card">
        <div class="text-center">
            
         </div>
        <div class="text-center bg-primary btn">
            <h1 class="text-white"><?php echo e($client['type']); ?></h1>
         </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item"><?php echo e($client['name']); ?></li>
        <li class="list-group-item"><?php echo e($client['surname']); ?></li>
        <li class="list-group-item"><?php echo e($client['patronymic']); ?></li>
        <li class="list-group-item"><?php echo e($client['patronymic']); ?></li>
        <li class="list-group-item"><?php echo e($client['email']); ?></li>
        <li class="list-group-item"><?php echo e($client['dob']); ?></li>
        <li class="list-group-item"><?php echo e($client['phone_number']); ?></li>
        <li class="list-group-item"><?php echo e($client['passport_series']); ?></li>
        <li class="list-group-item"><?php echo e($client['passport_number']); ?></li>
        <li class="list-group-item"><?php echo e($client['passport_issued']); ?></li>
        <li class="list-group-item"><?php echo e($client['passport_d_issue']); ?></li>

    </ul>
    <?php if(isset($client['address'])): ?>
    <?php $__currentLoopData = $client['address']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="text-center bg-primary btn">
       <h1 class="text-white"><?php echo e(__($address['type'])); ?></h1>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item"><?php echo e($address['city']); ?></li>
        <li class="list-group-item"><?php echo e($address['street']); ?></li>
        <li class="list-group-item"><?php echo e($address['house']); ?></li>
        <li class="list-group-item"><?php echo e($address['frame']); ?></li>
        <li class="list-group-item"><?php echo e($address['quarter']); ?></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="text-center bg-primary btn">
        <h1 class="text-white"><?php echo e(__('Documents')); ?></h1>
     </div>
     <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <a href="<?php echo e(route('adminGetQuestionnaire',[$id,1])); ?>">
                Анкета 1
             </a>
             <a href="<?php echo e(route('adminGetQuestionnaire',[$id,1])); ?>" target="_blank" download="Анкета1">
                <i class="fa fa-download" aria-hidden="true"></i>
             </a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('adminGetQuestionnaire',[$id,2])); ?>">
                Анкета 2
             </a>
             <a href="<?php echo e(route('adminGetQuestionnaire',[$id,2])); ?>" target="_blank" download="Анкета2">
                <i class="fa fa-download" aria-hidden="true"></i>
             </a>
        </li>
        <li class="list-group-item">
             <a title="document1" href="<?php echo e(route('getWord',[$id,1])); ?>" target="_blank" download="document1">
                <i class="fa fa-download" aria-hidden="true"></i>
             </a>
        </li>
        <li class="list-group-item">
            <a title="Договор_на_оказание_платных_медицинских_услуг_двусторон_с_физ_лицом" href="<?php echo e(route('getWord',[$id,2])); ?>" target="_blank" download="Договор_на_оказание_платных_медицинских_услуг_двусторон_с_физ_лицом">
               <i class="fa fa-download" aria-hidden="true"></i>
            </a>
       </li>
       <li class="list-group-item">
            <a title="Договор_на_оказание_платных_медицинских_услуг_несовершен_до_18_лет" href="<?php echo e(route('getWord',[$id,3])); ?>" target="_blank" download="Договор_на_оказание_платных_медицинских_услуг_несовершен_до_18_лет">
            <i class="fa fa-download" aria-hidden="true"></i>
            </a>
        </li>
        <li class="list-group-item">
            <a title="Согласие субъекта персональных данных на обработку его персональных данных" href="<?php echo e(route('getWord',[$id,4])); ?>" target="_blank" download="Согласие субъекта персональных данных на обработку его персональных данных">
               <i class="fa fa-download" aria-hidden="true"></i>
            </a>
        </li>
        <li class="list-group-item">
            <a title="ИДС для ДЕТЕЙ" href="<?php echo e(route('getWord',[$id,5])); ?>" target="_blank" download="ИДС для ДЕТЕЙ">
               <i class="fa fa-download" aria-hidden="true"></i>
            </a>
        </li>
        <li class="list-group-item">
            <a title="ИДС Общее (стоматология)" href="<?php echo e(route('getWord',[$id,6])); ?>" target="_blank" download="ИДС Общее (стоматология)">
               <i class="fa fa-download" aria-hidden="true"></i>
            </a>
        </li>
    </ul>
        <div class="card-body">
    
    <form action="<?php echo e(route('client.destroy',$client['id'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
     <button class="btn btn-sm btn-danger">
        <i class="fa fa-trash" aria-hidden="true"></i>
     </button>
    </form>
        </div>

    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\stom\resources\views/admin/client/show.blade.php ENDPATH**/ ?>