


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="header">
        <div class="whole_document">
            <div class="from_the_visit">
                <div class="from_the_visit_text">
                    <p>Заполнить</p>
                    <p>документы перед</p>
                    <p>первым визитом</p>
                </div>
                <div class="text_secondary">
                    <div class="yellow">
                       <i> Онлайн</i>
                    </div>
                    <div class="yellow_img">
                        <img src="<?php echo e(asset('images/flag.svg')); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="box_text">
            <p> Пожалуйста, внесите данные в форму. <br>
                Документы будут полностью готовы к вашему приезду в клинику.</p>
                <p> <b>Важно!</b> На первый визит с несовершеннолетним обязательно должны прийти <br> родители или законные представители (опекуны, усыновители или попечители).</p>
                <p>Необходимо принести оригиналы документов: паспорт законного представителя и <br> паспорт или свидетельство о рождении ребенка/ постановление органов опеки/ <br>
                    свидетельство о государственной регистрации акта усыновления ст. 125 СК РФ</p>
        </div>
    </div>
</div>


<form action="<?php echo e(route('client.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  <div class="container">
      <div class="user_login_div">
        <div class="user_login">
            <span class="user_title">Ваши данные (Данные родителя)</span>

               <div class="user_login_box">
                  <div class="user_login_input">
                      <label for="">Фамилия</label>
                      <input type="text" name="surname">
                      <?php if($errors->has('surname')): ?>
                       <span class="invalid-feedback" style="display: block;" role="alert">
                          <strong><?php echo e($errors->first('surname')); ?></strong>
                       </span>
                      <?php endif; ?>
                  </div>
                  <div class="user_login_input">
                      <label for="">Имя</label>
                      <input type="text" name="name">
                      <?php if($errors->has('name')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('name')); ?></strong>
                      </span>
                     <?php endif; ?>
                  </div>
                  <div class="user_login_input">
                      <label for="">Отчество</label>
                      <input type="text" name="patronymic">
                      <?php if($errors->has('patronymic')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('patronymic')); ?></strong>
                      </span>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="user_login_box">
                  <div class="user_login_input">
                      <label for="">Дата рождения</label>
                      <input type="date" name="dob">
                      <?php if($errors->has('dob')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('dob')); ?></strong>
                      </span>
                     <?php endif; ?>
                  </div>
                  <div class="user_login_input">
                      <label for="">Почта</label>
                      <input type="email" name="email">
                      <?php if($errors->has('email')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                     <?php endif; ?>
                  </div>
                  <div class="user_login_input">
                      <label for="">Ваш телефон</label>
                      <input type="number" name="phone_number">
                      <?php if($errors->has('phone_number')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('phone_number')); ?></strong>
                      </span>
                     <?php endif; ?>
                  </div>
               </div>

        </div>
        <div class="user_login">
          <span class="user_title">Паспортные данные</span>
          <div class="user_chckbox">
              <input type="checkbox" name="foreign_passport" value="1">
              <span>Паспорт иностранного образца</span>
          </div>

             <div class="user_login_box">
                <div class="user_login_input">
                    <label for="">Серия</label>
                    <input type="text" name="passport_series">
                    <?php if($errors->has('passport_series')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('passport_series')); ?></strong>
                      </span>
                     <?php endif; ?>
                </div>
                <div class="user_login_input  user_login_input_2">
                    <label for="">Номер</label>
                    <input type="number" name="passport_number">
                    <?php if($errors->has('passport_number')): ?>
                      <span class="invalid-feedback" style="display: block;" role="alert">
                         <strong><?php echo e($errors->first('passport_number')); ?></strong>
                      </span>
                     <?php endif; ?>
                </div>

             </div>
             <div class="user_login_box">
                <div class="user_login_input  user_login_input_2">
                    <label for="">Выдан</label>
                    <input type="text" name="passport_issued">
                    <?php if($errors->has('passport_issued')): ?>
                    <span class="invalid-feedback" style="display: block;" role="alert">
                       <strong><?php echo e($errors->first('passport_issued')); ?></strong>
                    </span>
                   <?php endif; ?>
                </div>
                <div class="user_login_input">
                    <label for="">Дата выдачи</label>
                    <input type="date" name="passport_d_issue">
                    <?php if($errors->has('passport_d_issue')): ?>
                    <span class="invalid-feedback" style="display: block;" role="alert">
                       <strong><?php echo e($errors->first('passport_d_issue')); ?></strong>
                    </span>
                   <?php endif; ?>
                </div>

             </div>
      </div>
      <div class="user_login">
        <span class="user_title">Адрес регистрации</span>


           <div class="user_login_box">
              <div class="user_login_input">
                  <label for="">город</label>
                  <input type="text" name="registration[city]">
              </div>
              <div class="user_login_input  user_login_input_2">
                  <label for="">улица</label>
                  <input type="text" name="registration[street]">
              </div>

           </div>
           <div class="user_login_box">
              <div class="user_login_input">
                  <label for="">дом</label>
                  <input type="text" name="registration[house]">
              </div>
              <div class="user_login_input">
                  <label for="">корп./стр.</label>
                  <input type="text" name="registration[frame]">
              </div>
              <div class="user_login_input">
                  <label for="">кв.</label>
                  <input type="text" name="registration[quarter]">
              </div>

           </div>
    </div>
    <div class="user_login">
        <span class="user_title">Адрес проживания</span>
        <div class="user_chckbox">
            <input type="checkbox">
            <span>совпадает с адресом регистрации</span>
        </div>

           <div class="user_login_box">
              <div class="user_login_input">
                  <label for="">город</label>
                  <input type="text" name="residence[city]">
              </div>
              <div class="user_login_input  user_login_input_2">
                  <label for="">улица</label>
                  <input type="text" name="residence[street]">
              </div>

           </div>
           <div class="user_login_box">
              <div class="user_login_input">
                  <label for="">дом</label>
                  <input type="text" name="residence[house]">
              </div>
              <div class="user_login_input">
                  <label for="">корп./стр.</label>
                  <input type="text" name="residence[frame]">
              </div>
              <div class="user_login_input">
                  <label for="">кв.</label>
                  <input type="text" name="residence[quarter]">
              </div>

           </div>
    <button class="user_btn">Далее</button>
    </div>
      </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style/treaty.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\stom\resources\views/treaty.blade.php ENDPATH**/ ?>