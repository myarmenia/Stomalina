

<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="table-responsive py-4">
        <table class="table table-flush" id="datatable-basic">
            <thead class="thead-light">
                <tr>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Surname')); ?></th>
                    <th><?php echo e(__('Patronymic')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <th><?php echo e(__('DOB')); ?></th>
                    <th><?php echo e(__('Phone Number')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($clients)): ?>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($client['name']); ?></td>
                        <td><?php echo e($client['surname']); ?></td>
                        <td><?php echo e($client['patronymic']); ?></td>
                        <td><?php echo e($client['email']); ?></td>
                        <td><?php echo e($client['dob']); ?></td>
                        <td><?php echo e($client['phone_number']); ?></td>
                        <td>
                            <a class="btn btn-sm btn-primary text-white" href="<?php echo e(route('client.show',$client['id'])); ?>">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('client.destroy',$client['id'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                             <button class="btn btn-sm btn-danger">
                                <i class="fa fa-trash" aria-hidden="true"></i>
                             </button>
                            </form>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Clients')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/admin/client/index.blade.php ENDPATH**/ ?>