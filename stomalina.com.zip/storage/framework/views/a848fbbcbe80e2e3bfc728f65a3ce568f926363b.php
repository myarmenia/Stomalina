

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="py-4">
    <form method="POST" action="<?php echo e(route('doctors.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" placeholder="<?php echo e(__('Name')); ?>" name="name">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" placeholder="<?php echo e(__('Middlename')); ?>" name="middlename">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <input type="text" class="form-control form-control-alternative" placeholder="<?php echo e(__('Surname')); ?>" name="surname">
                </div>
              </div>
        </div>
         <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="avatar">
                        <label class="custom-file-label"><?php echo e(__('Choose Avatar')); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <textarea class="form-control form-control-alternative" rows="3" placeholder="<?php echo e(__('Job Title')); ?>" name="job_title"></textarea>
            </div>
        </div>
        <div class="py-4">
          <div class="row">
            <div class="col-md-6">
              <div class="column-2a">
                <h2><?php echo e(__('Education')); ?></h2>
                  <table class="table-style" id="education_ap">
                  </table>
                  <div class="form-group py-3">
                    <div class="custom-file">
                        <input type="text" class="form-control form-control-alternative" id="education_inp" placeholder="<?php echo e(__('Add Education')); ?>">
                        <input type="number" class="form-control form-control-alternative py-3" min="1900" max="2099" id="education_date_inp">
                        <button class="btn" type="button" onclick="addDesc('education')"><?php echo e(__('Add')); ?></button>
                    </div>
                </div>
                </div>
            </div>
            <div class="col-md-6">
              <div class="column-2a">
                <h2><?php echo e(__('Training')); ?></h2>
                  <table class="table-style" id="training_ap">
                  </table>
                  <div class="form-group py-3">
                    <div class="custom-file">
                        <input type="text" class="form-control form-control-alternative" id="training_inp" placeholder="<?php echo e(__('Add Training')); ?>">
                        <input type="number" class="form-control form-control-alternative py-3" min="1900" max="2099" id="training_date_inp">
                        <button class="btn" type="button" onclick="addDesc('training')"><?php echo e(__('Add')); ?></button>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="row py-4 text-center">
            <div class="col-md-12">
                <button class="btn btn-primary">
                    <?php echo e(__('Save')); ?>

                </button>
            </div>
        </div>
       
      </form>
    </div>
</div>
<script>
  let educationDesc = 0;
  let trainingDesc = 0;
</script>
<script src="<?php echo e(asset('js/doctor/create.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['title' => __('Create Doctor')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\stomalina.com\resources\views/admin/doctors/create.blade.php ENDPATH**/ ?>