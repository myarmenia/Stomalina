Admin Login & Password
/executive/login
//1
admin@stomalina.com
stomalina1234

//2
admin@stomalina.ru
stomalina1234

//3
test@test.ru
test